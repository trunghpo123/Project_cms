<div class="no-post">
    <?php _e('Nothing post found','trungcap'); ?>
</div>

