<?php 
    /*template name:shop*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/11-12','content') ?>;
<?php get_footer();?>