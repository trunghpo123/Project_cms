<?php 
    /*template name:ABOUT*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/14','content') ?>;
<?php get_footer();?>