<?php 
    /*template name:contact*/
    
?>
<?php get_header(); ?>
<?php get_template_part('modul/17','content') ?>;
<?php get_template_part('modul/18','content') ?>;
<?php get_footer();?>