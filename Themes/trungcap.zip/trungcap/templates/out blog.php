<?php 
    /*template name:OUT BLOG*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/19','content') ?>;
<?php get_template_part('modul/20','content') ?>;
<?php get_footer();?>