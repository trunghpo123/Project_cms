<?php 
    /*template name:blog*/
    
?>
<?php get_header(); ?>

<?php get_template_part('modul/21-22-23','content') ?>;
<?php get_footer();?>