
<div class="type-19" style="background-image: url(<?php echo(get_template_directory_uri()); ?>/images/19/19.jpg);">
    <div class="container">
            <div class="Stores">
                <div class="word">
                    <h3>
                        Our Stores
                    </h3>
                </div>
                <div class="borders">

                </div>
                <div class="icon">
                    <a href="#">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                    <a href="#">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a class="#">
                        <i class="fa fa-envelope-o" aria-hidden="true"></i>
                    </a>
                    <a class="#">
                        <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                    </a>
                    <a class="#">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
    </div>
</div>
