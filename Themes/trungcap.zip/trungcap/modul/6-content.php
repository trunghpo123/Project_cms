
<div class="type-6">
    <div class="container">
        <div class="row">
            <div class="section-title">
                <b></b>
                <span class="title-main">Latest news </span>
                <b></b>
            </div>
            <div class="type-6">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/1.jpg"  class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5> Wellcome to my</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    
                                    Welcome to WordPress. This is your first post. Edit or delete it, then start blogging! [...]					
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    1 Comment                        
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/2.jpg"  class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5> Just another post with A Gallery</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed vulputate massa. Fusce ante magna, [...]						
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    3 Comment                        
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/3.jpg" class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5>A Simple Blog Post</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut [...]										
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    2 Comment                        
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/4.jpg" class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="video">
                                    <i class="fa fa-play-circle-o" aria-hidden="true"></i>
                                </div>
                                <div class="product-rating">
                                    <h5>A Video Blog Post</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed vulputate massa. Fusce ante magna, [...]									
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    1 Comment                        
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/5.jpg"  class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5>Just a cool blog post with Images</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed vulputate massa. Fusce ante magna, [...]										
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    5 Comment                        
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/6.jpg" w class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5>Another post with A Gallery</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed vulputate massa. Fusce ante magna, [...]					
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    4 Comment                        
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/7.jpg"  class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5>New Client Landed</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut [...]									
                                    </span>
                                </div>
                                <div class="product-title"> 
                                                      
                                </div>
                            </div>
                        </div>
                          <div class="swiper-slide">
                            <div class="product-item1">
                                <div class="product-image2">
                                    <a href="#"><img  src="<?php echo(get_template_directory_uri()); ?>/images/6/8.jpg" class="img-responsive" alt="">
                                    </a> 
                                </div>
                                <div class="hird">
                                    <div class="heard" style="">
                                        <a class="#"><span>13</span></a>
                                    </div>
                                    <div class="heard">
                                        <a class="#"><span>Otc</span></a>
                                    </div> 
                                </div>
                                <div class="product-rating">
                                    <h5> An Amazing responsive and Retina ready theme.</h5>
                                </div>
                                <div class="borders">

                                </div>
                                <div class="product-price">
                                    <span>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sed eleifend risus, sit amet porttitor [...]					
                                    </span>
                                </div>
                                <div class="product-title"> 
                                    1 Comment                        
                                </div>
                            </div>
                        </div>
                        
                    </div>
                     <div class="btn">
                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev" ></div>
                    <div class="swiper-button-next"></div>
                </div>
                </div>
                </div>
               
            
        </div>
    </div>
</div>
<script>

    var swiper = new Swiper('.swiper-container', {
        spaceBetween: 50,
        slidesPerView: 6,
        slidesPerGroup: 2,
        loop: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            // when window width is >= 320px
            320: {
                slidesPerView: 2,
                spaceBetween: 20
            },
            // when window width is >= 480px
            720: {
                slidesPerView: 4,
                spaceBetween: 30
            },
            // when window width is >= 640px
            1040: {
                slidesPerView: 4,
                spaceBetween: 40
            },
        }
    });
</script>
