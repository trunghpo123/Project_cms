jQuery(document).ready(function() {
        jQuery('nav.primary-menu ul.sf-menu').superfish();
});